<?php
header('Content-Type: text/html; charset=utf-8');

// ---------------------------------------------------------------------------------------------
// Insertem aquestes dades a la base de dades
// ---------------------------------------------------------------------------------------------
      $host = "localhost";
      $port = "3306";
      $usuari = "root";
      $contrasenya = "Tabarnia2018";
      $base ="newsletters_db";
      $taula = "newsletters";
	
      function Conectarse()
      {
								 echo "<strong>----------------------------------------------------------------<br />Informació sobre la base de dades:<br />----------------------------------------------------------------<br /></strong>";
         global $host, $port, $usuari, $contrasenya, $base, $taula;
 
         if (!($link = mysqli_connect($host.":".$port, $usuari, $contrasenya))) 
         { 
            echo "<font color='red'>Error conectando a la base de datos.</font><br>"; 
            exit(); 
            }
         else
         {
            echo "Hem connectat amb la base de dades.";
         }
         if (!mysqli_select_db($link, $base)) 
         { 
            echo "<font color='red'>Error seleccionando la base de datos.</font><br>"; 
            exit(); 
         }
         else
         {
            echo "Hem pogut obrir la base de dades $base sense problemes.<br>";
         }
      return $link; 
      } 
 
      $link = Conectarse();
						
						$query1 = "SELECT id, data, titol, cos FROM $taula;";
      $resultat = mysqli_query($link, $query1); 
      ?>
 
      <table>
         <tr>
            <td>id</td>
            <td>data</td>
												<td>titol</td>
												<td>cos</td>
         <tr>
 
									<?php
				
									while($row = mysqli_fetch_array($resultat))
									{ 
												echo "<tr>";
												echo "<td>";
												echo $row["id"];
												echo "</td>";
												echo "<td>";
												echo $row["data"];
												echo "</td>";
												echo "<td>";
												echo $row["titol"];
												echo "</td>";
												echo "<td>";
												echo $row["cos"];
												echo "</td>";
												echo "</tr>";
									} 
				
									mysqli_free_result($resultat); 
									mysqli_close($link);
									?>
						</table>