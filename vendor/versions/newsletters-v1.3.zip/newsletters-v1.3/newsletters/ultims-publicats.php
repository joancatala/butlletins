		<!-- Cap de la web -->		
		<?php include "vendor/inc/cap.inc"; ?>

		<!-- Menú de la web -->		
		<?php include "vendor/inc/menu.inc"; ?>

		<!-- Connexió a la base de dades -->		
		<?php include "vendor/inc/connexio.inc"; ?>

		<!-- Primer enllaç a la base de dades -->		
		<?php include "vendor/inc/link.inc"; ?>
  
      <section class="resume-section p-3 p-lg-5 d-flex d-column" id="about"><div>
        
      <?php
		$consulta1 = "SELECT id, data, titol, cos FROM $taula order by id desc limit 3;";
		$resultat = mysqli_query($link, $consulta1); 
				
		while($row = mysqli_fetch_array($resultat))
		{
    	?>
    
      <div class="resume-item d-flex flex-column flex-md-row mb-5">
      <div class="resume-content mr-auto">
      
      <?php
      //echo $row["id"];
      echo "<h3 class='mb-0'>". $row["titol"] . "</h3>";
      echo "<span class='text-primary'>". $row["data"] ."</span><br />";
      echo "<div>". $row["cos"] ."</div><br />";
      } 
				
      mysqli_free_result($resultat); 
      mysqli_close($link);
      ?>
        
        
      </div></section>

		<!-- Peu de la web -->		
		<?php include "vendor/inc/peu.inc"; ?>


























