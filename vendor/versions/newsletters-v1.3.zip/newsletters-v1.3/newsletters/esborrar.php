<?php

//agafem el codi del butlletí
$id_newsletter=($_GET[codi]);

if (($id_newsletter)) {
    echo "<h1>".$id_newsletter."</h1>";
}

<h1>texto</h1>

?>